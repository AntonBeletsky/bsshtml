    // Initialize Bootstrap carousel
    document.addEventListener('DOMContentLoaded', function () {
        var carouselElement = document.querySelector('#heroCarousel');
        var carousel = new bootstrap.Carousel(carouselElement, {
            interval: 5000, // Slide every 5 seconds
            wrap: true // Loop back to first slide
        });
    });