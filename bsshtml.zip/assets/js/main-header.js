/*document.addEventListener("DOMContentLoaded", function() {
    const header = document.querySelector("header.main-header");
    if (!header) return;

    const breakpoints = {
        xs: 0,   // Extra small (default)
        sm: 576, // Small
        md: 768, // Medium
        lg: 992, // Large
        xl: 1200,// Extra large
        xxl: 1400 // Extra extra large
    };

    // Define which breakpoints should apply the height adjustment
    const activeBreakpoints = ["lg", "xl", "xxl"];

    // Get viewport width
    const viewportWidth = window.innerWidth;

    // Check if viewport is within the defined active breakpoints
    const shouldApply = activeBreakpoints.some(bp => viewportWidth >= breakpoints[bp]);

    if (shouldApply) {
        const headerHeight = header.offsetHeight;

        // Apply padding to the body to prevent overlap with fixed header
        document.body.style.paddingTop = `${headerHeight}px`;
    }
});
*/

/* for 
body {
    padding-top: var(--header-height);
}
*/

const header = document.querySelector("header.main-header");
const headerHeight = header.offsetHeight;

document.documentElement.style.setProperty("--header-height", `${headerHeight}px`);

